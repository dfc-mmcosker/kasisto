function envProperties() {
  
  var APP_AUTH_KEY = "c44402bd-9b89-476c-a534-6ce92f7b0558";
  var APP_AUTH_HEADER = "secret";
  var optionalAssistantName = "dfc-academy";
  var optionalAssistantTarget = "stage";

  var env =
  {
    "SERVER_CONFIG":
    {
      SERVER_URL: 'https://q2-en-us-prod-api.kitsys.net/kai/api/v2/capi',
      APP_AUTH_HEADER: APP_AUTH_HEADER,
      APP_AUTH_KEY: APP_AUTH_KEY,
      SPEECH_RECOGNITION_SERVER: 'https://kai-en-us-speech-to-text-service-qa.kitsys.net/recognizeWebview'

    }
  };

  if (optionalAssistantName) {
    env.SERVER_CONFIG.assistant_name = optionalAssistantName;
  }
  if (optionalAssistantTarget) {
    env.SERVER_CONFIG.assistant_target = optionalAssistantTarget;
  }

  // use for development only to bypass exception of missing platform.user_id and device.type in CAPI context.
  document.addEventListener("DOMContentLoaded", function (event) {
    // use for development only to bypass exception of missing platform.user_id and device.type in CAPI context.
    execNativeMethod = (nativeFunctionName, params) => {
      if (nativeFunctionName == "webviewReady") {
        kserver.CoreAPI.updateContext({
          "device": { "type": "web" },
          "platform": { "user_id": "Sample Glia user id" }
        });

        webviewLibraryGliaAdapterNativeMethod(nativeFunctionName, params)
      }
    }
  });

  return env;
}

if (typeof module !== 'undefined') {
  module.exports = new envProperties();

}
